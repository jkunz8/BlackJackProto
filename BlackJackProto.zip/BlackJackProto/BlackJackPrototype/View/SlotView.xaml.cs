﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Timers;
using System.Threading;


namespace BlackJackPrototype.View
{
    /// <summary>
    /// Interaction logic for SlotView.xaml
    /// </summary>
    public partial class SlotView : UserControl
    {
        public SlotView()
        {
            InitializeComponent();
        }

        static int slot1;
        static int slot2;
        static int slot3;

        private void Slt1_TextChanged(object sender, TextChangedEventArgs e)
        {
            slt1.Text = Convert.ToString(slot1);
        }

        private void Slt2_TextChanged(object sender, TextChangedEventArgs e)
        {
            slt2.Text = Convert.ToString(slot2);
        }

        private void Slt3_TextChanged(object sender, TextChangedEventArgs e)
        {
            slt3.Text = Convert.ToString(slot3);
        }

        private void strt_Click(object sender, RoutedEventArgs e)
        {
            //slottimer.Enabled = true;

            Random rnd = new Random();

            slot1 = rnd.Next(0, 9);
            slot2 = rnd.Next(0, 9);
            slot3 = rnd.Next(0, 9);

            bool a = Convert.ToBoolean(slot1);
            bool b = Convert.ToBoolean(slot2);
            bool c = Convert.ToBoolean(slot3);

            if (a == b == c)
            {
                _ = MessageBox.Show("You Win");
            }
            else
            {
                _ = MessageBox.Show("You Lose");
            }

        }

        private void slottimer_Tick(object sender, EventArgs e)
        {

        }
    }
}
