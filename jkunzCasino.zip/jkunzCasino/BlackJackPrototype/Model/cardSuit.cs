﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BlackJackPrototype.Model
{
    public enum cardSuit
    {
        Hearts,
        Diamonds,
        Clubs,
        Spades
    }
}
